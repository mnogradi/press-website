#import "template.typ": *

= Your Short Story Title

|Lorem ipsum dolor| sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.

To type an em-dash, simply type two hyphens back-to-back--like this. The template will automatically convert them into a professional, continuous em-dash without you having to hunt for the special character on your keyboard!

Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. 

+++

This is a new scene. The three plus signs on their own line above automatically generated the subtle, professional scene break you see here. 

#q("He who would valiant be 'gainst all disaster,
Let him in constancy follow the Master.")

Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. 

|The End|
