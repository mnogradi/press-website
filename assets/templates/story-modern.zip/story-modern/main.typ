#import "template.typ": book, verse, scene-break

// ==============================
// BOOK SETUP (EDIT THIS SECTION)
// ==============================

#show: book.with(
  title: "Your Story Title",
  author: "Author Name",
  year: "2026",
  font-size: 11pt,
  // paper-size: "6x9", // Other common sizes: "5x8", "5.5x8.5"
  // inner-margin: 1.25in, // Adjust this if the binding gutter is too small/large
)


#include "story.typ"
